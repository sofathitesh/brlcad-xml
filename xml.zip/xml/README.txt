Read this simple step to install plugin in wordpresss.

1) Install wordpress

2) Login into wordpress
 
3) Click into plugin and select add new plugin

plugin->add new->upload

4) Select your plugin (in zip format) and click on Install now.

5) Click on activate. and activate your plugin.

6) Click on xml parser tab (in admin menu) and set the brlcad article and doc stylesheet path.

7) Now create new post and add this shortcode in post [search].

8) Now visit in your web site and check the all changes.



Read this simple step to intsall pligin in wordpress (manually)

1) Install wordpress.

2) Download plugin.

3) extract the plugin into wordpress /wordpress_floder/wp-content/plugins/

4) Login into wordpress and activate the plugin.

5) Click on xml parser tab (in admin menu) and set the brlcad article and doc stylesheet path.

6) Now create new post and add this shortcode in post [search].

7) Now visit in your web site and check the all changes.

